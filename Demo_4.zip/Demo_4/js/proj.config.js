var Config = {};
Config.categories =  ["行为", "器件", "故障"];